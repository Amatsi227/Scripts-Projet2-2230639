using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DLLChess;

public class YourPawn : Pawn
{
    /// <summary>
    /// Determine les deplacements du pionn
    /// </summary>
    /// <param name="x">Cordonée de depart x sur l'echequier</param>
    /// <param name="y">Coordonnée de depart y sur l'echequier</param>
    /// <returns>Liste des mouvements possibles du pion</returns>
    public override List<Move> GetAvailableMoves(int x, int y)
    {
        //TODO Retirer le return actuel afin de programmer votre propre fonction pour le pion
        //La fonction devra retourner currentPossibleMoves (return currentPossibleMove;)

        int direction;

        if (myColor == Piece.Color.White)
        {
            // vers le bas
            direction = -1;
        }
        else
        {
            // vers le haut
            direction = 1;
        }

        // Deplacement en avant
        if (VerifierDeplacement(x, y + direction))
        {
            //AddPossibleMoveToList(x, y + direction);

            // Deplacement de deux cases depuis la position de départ
            if ((myColor == Piece.Color.White && y == 6) || (myColor == Piece.Color.Black && y == 1))
            {
                VerifierDeplacement(x, y + 2 * direction);
            }
        }

        // Diagonales
        VerifierDiagonale(x + 1, y + direction);
        VerifierDiagonale(x - 1, y + direction);

        return currentPossibleMove;

        //return base.GetAvailableMoves(x, y);
    }

    /// <summary>
    /// Verifie si la case est libre et est dans les limites du board
    /// </summary>
    /// <param name="positionX">Cordonnee X</param>
    /// <param name="positionY">Coordonnee Y</param>
    /// <returns>Vrai si conditions respectees, Faux sinon</returns>
    private bool VerifierDeplacement(int positionX, int positionY)
    {
        if (positionX >= 0 && positionX < 8 && positionY >= 0 && positionY < 8 && MyBoard.GetBoardState()[positionX, positionY].MyPiece == null)
        {
            AddPossibleMoveToList(positionX, positionY);
            return true;
        }
        return false;
    }

    /// <summary>
    /// Verifie si la case contient une piece adverse et est dans les limites du board
    /// </summary>
    /// <param name="positionX">Coordonnee x</param>
    /// <param name="positionY">Coordonnee y</param>
    private void VerifierDiagonale(int positionX, int positionY)
    {
        if (positionX >= 0 && positionX < 8 && positionY >= 0 && positionY < 8 &&
            MyBoard.GetBoardState()[positionX, positionY].MyPiece != null &&
            MyBoard.GetBoardState()[positionX, positionY].MyPiece.myColor != myColor)
        {
            AddPossibleMoveToList(positionX, positionY);
        }
    }


}
