using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DLLChess;

public class YourKing : King
{
    public override List<Move> GetAvailableMoves(int x, int y)
    {
        //TODO Retirer le return actuel afin de programmer votre propre fonction pour le roi
        //La fonction devra retourner currentPossibleMoves (return currentPossibleMove;)

        // Deplacemennt vers la droite
        VerifierDeplacement(x + 1, y);

        // Deplacement vers la gauche
        VerifierDeplacement(x - 1, y);

        // Deplacement vers le haut
        VerifierDeplacement(x, y + 1);

        // Deplacement vers le bas
        VerifierDeplacement(x, y - 1);

        // Deplacement vers la diagonale haut-droite
        VerifierDeplacement(x + 1, y + 1);

        // Deplacement vers la diagonale haut-gauche
        VerifierDeplacement(x - 1, y + 1);

        // Deplacement vers la diagonale bas-droite
        VerifierDeplacement(x + 1, y - 1);

        // Deplacement vers la diagonale bas-gauche
        VerifierDeplacement(x - 1, y - 1);


        //return base.GetAvailableMoves(x, y);
        return currentPossibleMove;
    }


    private bool VerifierDeplacement(int positionX, int positionY)
    {
        // Check si la position est dans les limites du board
        if (positionX >= 0 && positionX < 8 && positionY >= 0 && positionY < 8)
        {
            if (MyBoard.GetBoardState()[positionX, positionY].MyPiece == null)
            {
                AddPossibleMoveToList(positionX, positionY);
                return true;
            }
            else
            {
                if (MyBoard.GetBoardState()[positionX, positionY].MyPiece.myColor != myColor)
                {
                    AddPossibleMoveToList(positionX, positionY);
                }
                return false;
            }
        }
        return false;
    }

}
