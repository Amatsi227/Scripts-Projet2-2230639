using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DLLChess;

public class YourRook : Rook
{
    /// <summary>
    /// Determine les deplacements de la tour
    /// </summary>
    /// <param name="x">Cordonée de depart x sur l'echequier</param>
    /// <param name="y">Coordonnée de depart y sur l'echequier</param>
    /// <returns>Liste des mouvements possibles de la tour</returns>
    public override List<Move> GetAvailableMoves(int x, int y)
    {
        //TODO Retirer le return actuel afin de programmer votre propre fonction pour la tour
        //La fonction devra retourner currentPossibleMoves (return currentPossibleMove;)

        // Deplacement vers la droite
        for (int i = x + 1; i < 8; i++)
            if (!VerifierDeplacement(i, y))
                break;

        // Deplacement vers la gauche
        for (int i = x - 1; i >= 0; i--)
            if (!VerifierDeplacement(i, y))
                break;

        // Deplacement vers le haut
        for (int i = y + 1; i < 8; i++)
            if (!VerifierDeplacement(x, i))
                break;

        // Deplacement vers le bas
        for (int i = y - 1; i >= 0; i--)
            if (!VerifierDeplacement(x, i))
                break;

        //return base.GetAvailableMoves(x, y);

        return currentPossibleMove;
    }

    /// <summary>
    /// Verifie si la case est libre et que la case contient une piece adverse
    /// </summary>
    /// <param name="x">CoordonneeX</param>
    /// <param name="y">CoordonneeY</param>
    /// <returns>vrai / Faux</returns>
    private bool VerifierDeplacement(int  x, int y)
    {
        if (MyBoard.GetBoardState()[x, y].MyPiece == null)
        {
            AddPossibleMoveToList(x, y);
            return true;
        }

        else
        {
            if (MyBoard.GetBoardState()[x, y].MyPiece.myColor != myColor)
            {
                AddPossibleMoveToList(x, y);
            }
            return false;
        }
    }
}
