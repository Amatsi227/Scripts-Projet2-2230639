using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DLLChess;

public class YourQueen : Queen
{
    public override List<Move> GetAvailableMoves(int x, int y)
    {
        //TODO Retirer le return actuel afin de programmer votre propre fonction pour la reine
        //La fonction devra retourner currentPossibleMoves (return currentPossibleMove;)

        //Deplacement vers la droite
        for (int i = x + 1; i < 8; i++)
        {
            if (!VerifierDeplacement(i, y))
            {
                break;
            }
        }

        // Deplacement vers la gauche
        for (int i = x - 1; i >= 0; i--)
        {
            if (!VerifierDeplacement(i, y))
            {
                break;
            }
        }

        // Deplacment vers le haut
        for (int i = y + 1; i < 8; i++)
        {
            if (!VerifierDeplacement(x, i))
            {
                break;
            }
        }

        // Deplacement vers le bas
        for (int i = y - 1; i >= 0; i--)
        {
            if (!VerifierDeplacement(x, i))
            {
                break;
            }
        }

        // Deplacement diagonal haut-droite
        for (int i = 1; x + i < 8 && y + i < 8; i++)
        {
            if (!VerifierDeplacement(x + i, y + i))
            {
                break;
            }
        }

        // Deplacement diagonal haut-gauche
        for (int i = 1; x - i >= 0 && y + i < 8; i++)
        {
            if (!VerifierDeplacement(x - i, y + i))
            {
                break;
            }
        }

        // Deplacement diagonal bas-gauche
        for (int i = 1; x - i >= 0 && y - i >= 0; i++)
        {
            if (!VerifierDeplacement(x - i, y - i))
            {
                break;
            }
        }

        // Deplacement diagonal bas-droite
        for (int i = 1; x + i < 8 && y - i >= 0; i++)
        {
            if (!VerifierDeplacement(x + i, y - i))
            {
                break;
            }
        }


        //return base.GetAvailableMoves(x, y);
        return currentPossibleMove;
    }

    private bool VerifierDeplacement(int x, int y)
    {
        if (MyBoard.GetBoardState()[x, y].MyPiece == null)
        {
            AddPossibleMoveToList(x, y);
            return true;
        }

        else
        {
            if (MyBoard.GetBoardState()[x, y].MyPiece.myColor != myColor)
            {
                AddPossibleMoveToList(x, y);
            }
            return false;
        }
    }
}
