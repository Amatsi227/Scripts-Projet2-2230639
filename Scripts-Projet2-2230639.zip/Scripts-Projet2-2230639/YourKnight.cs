using System.Collections.Generic;
using DLLChess;

public class YourKnight : Knight
{
    public override List<Move> GetAvailableMoves(int x, int y)
    {
        // Deplacement horizontale deux cases + 1 case vers le haut ou bas
        VerifierDeplacement(x + 2, y + 1);
        VerifierDeplacement(x + 2, y - 1);
        VerifierDeplacement(x - 2, y + 1);
        VerifierDeplacement(x - 2, y - 1);

        // Deplacement verticale d'une case + 2 cases vers le haut ou le bas
        VerifierDeplacement(x + 1, y + 2);
        VerifierDeplacement(x + 1, y - 2);
        VerifierDeplacement(x - 1, y + 2);
        VerifierDeplacement(x - 1, y - 2);

        return currentPossibleMove;

        //return base.GetAvailableMoves(x, y);
    }


    private bool VerifierDeplacement(int positionX, int positionY)
    {
        // Check si la position est dans les limites du board
        if (positionX >= 0 && positionX < 8 && positionY >= 0 && positionY < 8)
        {
            if (MyBoard.GetBoardState()[positionX, positionY].MyPiece == null)
            {
                AddPossibleMoveToList(positionX, positionY);
                return true;
            }
            else
            {
                if (MyBoard.GetBoardState()[positionX, positionY].MyPiece.myColor != myColor)
                {
                    AddPossibleMoveToList(positionX, positionY);
                }
                return false;
            }
        }
        return false;
    }
}
